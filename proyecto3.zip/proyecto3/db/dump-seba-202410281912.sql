--
-- PostgreSQL database dump
--

-- Dumped from database version 17.0
-- Dumped by pg_dump version 17.0

-- Started on 2024-10-28 19:12:28

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 4 (class 2615 OID 2200)
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- TOC entry 4865 (class 0 OID 0)
-- Dependencies: 4
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 220 (class 1259 OID 16427)
-- Name: asistencias; Type: TABLE; Schema: public; Owner: seba
--

CREATE TABLE public.asistencias (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    justificacion character varying(255),
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL,
    presente boolean NOT NULL
);


ALTER TABLE public.asistencias OWNER TO seba;

--
-- TOC entry 219 (class 1259 OID 16426)
-- Name: asistencias_id_seq; Type: SEQUENCE; Schema: public; Owner: seba
--

CREATE SEQUENCE public.asistencias_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.asistencias_id_seq OWNER TO seba;

--
-- TOC entry 4866 (class 0 OID 0)
-- Dependencies: 219
-- Name: asistencias_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seba
--

ALTER SEQUENCE public.asistencias_id_seq OWNED BY public.asistencias.id;


--
-- TOC entry 218 (class 1259 OID 16391)
-- Name: users; Type: TABLE; Schema: public; Owner: seba
--

CREATE TABLE public.users (
    id integer NOT NULL,
    "nombreCompleto" character varying(255) NOT NULL,
    telefono character varying(15) NOT NULL,
    cargo character varying(100) NOT NULL,
    "fechaIncorporacion" date,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.users OWNER TO seba;

--
-- TOC entry 217 (class 1259 OID 16390)
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: seba
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO seba;

--
-- TOC entry 4867 (class 0 OID 0)
-- Dependencies: 217
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seba
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- TOC entry 4703 (class 2604 OID 16430)
-- Name: asistencias id; Type: DEFAULT; Schema: public; Owner: seba
--

ALTER TABLE ONLY public.asistencias ALTER COLUMN id SET DEFAULT nextval('public.asistencias_id_seq'::regclass);


--
-- TOC entry 4700 (class 2604 OID 16394)
-- Name: users id; Type: DEFAULT; Schema: public; Owner: seba
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- TOC entry 4859 (class 0 OID 16427)
-- Dependencies: 220
-- Data for Name: asistencias; Type: TABLE DATA; Schema: public; Owner: seba
--

COPY public.asistencias (id, "userId", justificacion, "createdAt", "updatedAt", presente) FROM stdin;
\.


--
-- TOC entry 4857 (class 0 OID 16391)
-- Dependencies: 218
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: seba
--

COPY public.users (id, "nombreCompleto", telefono, cargo, "fechaIncorporacion", "createdAt", "updatedAt") FROM stdin;
1	Sebastian Muñozz E	000000000	Empleado	\N	2024-10-28 14:59:04.086247-03	2024-10-28 14:59:04.086247-03
2	felipe sagredo	000000000	Empleado	\N	2024-10-28 14:59:04.086247-03	2024-10-28 14:59:04.086247-03
3	Juan Pérez	123456789	Gerente de Ventas	2023-10-01	2024-10-28 14:59:54.744079-03	2024-10-28 14:59:54.744079-03
7	seba muñoz	96824353	cocinero	2025-10-01	2024-10-28 15:19:13.452031-03	2024-10-28 15:19:13.452031-03
8	ignacio muñoz	96824353	cocinero	2025-10-01	2024-10-28 15:40:57.477175-03	2024-10-28 15:40:57.477175-03
9	ignacio muñoz	96824353	cocinero	2025-10-01	2024-10-28 15:47:33.958529-03	2024-10-28 15:47:33.958529-03
10	ignacio muñoz	96824353	cocinero	2025-10-01	2024-10-28 17:49:26.93572-03	2024-10-28 17:49:26.93572-03
11	ign muñoz	96824353	cocinero	2025-10-01	2024-10-28 18:14:00.231666-03	2024-10-28 18:14:00.231666-03
12	seba	96824353	cocinero	2025-10-01	2024-10-28 18:38:56.92527-03	2024-10-28 18:38:56.92527-03
\.


--
-- TOC entry 4868 (class 0 OID 0)
-- Dependencies: 219
-- Name: asistencias_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seba
--

SELECT pg_catalog.setval('public.asistencias_id_seq', 1, false);


--
-- TOC entry 4869 (class 0 OID 0)
-- Dependencies: 217
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seba
--

SELECT pg_catalog.setval('public.users_id_seq', 12, true);


--
-- TOC entry 4707 (class 2606 OID 16400)
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: seba
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- TOC entry 4709 (class 2606 OID 16432)
-- Name: asistencias PK_f7eb09d44d6c7dd4ccc6eb29af8; Type: CONSTRAINT; Schema: public; Owner: seba
--

ALTER TABLE ONLY public.asistencias
    ADD CONSTRAINT "PK_f7eb09d44d6c7dd4ccc6eb29af8" PRIMARY KEY (id);


--
-- TOC entry 4710 (class 2606 OID 16433)
-- Name: asistencias FK_b36da10b527731de495b7725745; Type: FK CONSTRAINT; Schema: public; Owner: seba
--

ALTER TABLE ONLY public.asistencias
    ADD CONSTRAINT "FK_b36da10b527731de495b7725745" FOREIGN KEY ("userId") REFERENCES public.users(id);


-- Completed on 2024-10-28 19:12:28

--
-- PostgreSQL database dump complete
--

