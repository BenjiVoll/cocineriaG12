
export async function marcarAsistencia(req, res) {
    try {
        const { userId, presente, justificacion } = req.body;
        console.log("Datos recibidos:", { userId, presente, justificacion }); // Imprime los datos recibidos

        // Validar que el userId no sea nulo
        if (!userId) {
            return res.status(400).json({ message: "El userId es requerido." });
        }

        const asistencia = new Asistencia(); // Crea una nueva instancia de Asistencia
        asistencia.userId = userId; // Asegúrate de que la propiedad en la entidad corresponda
        asistencia.presente = presente;
        asistencia.justificacion = justificacion;

        const asistenciaRepository = AppDataSource.getRepository(Asistencia);
        await asistenciaRepository.save(asistencia); // Guarda la asistencia en la base de datos

        res.status(201).json({ message: "Asistencia registrada correctamente" });
    } catch (error) {
        console.error("Error al registrar asistencia:", error); // Imprime el error en la consola
        res.status(500).json({ message: "Error al registrar asistencia", error: error.message });
    }
}
