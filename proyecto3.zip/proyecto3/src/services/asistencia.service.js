// src/services/asistencia.service.js
import { AppDataSource } from '../config/configDB.js';
import Asistencia from '../entity/asistencia.entity.js';

export async function marcarAsistencia(userId, presente, justificativo = null) {
    const asistenciaRepository = AppDataSource.getRepository(Asistencia);

    const nuevaAsistencia = asistenciaRepository.create({
        fecha: new Date(),
        presente,
        justificativo,
        user: { id: userId } // Enlazamos la asistencia con el usuario mediante su ID
    });

    return await asistenciaRepository.save(nuevaAsistencia);
}
