import express from 'express';
import { marcarAsistencia } from '../controllers/asistencia.controller.js';

const router = express.Router();

router.post('/asistencia', marcarAsistencia); // Ruta para registrar asistencia

export default router; // Exportación por defecto
