"use strict";

import { EntitySchema } from "typeorm";

const AsistenciaSchema = new EntitySchema({
    name: "Asistencia",
    tableName: "asistencias",
    columns: {
        id: {
            type: "int",
            primary: true,
            generated: true,
        },
        userId: {
            type: "int",
            nullable: false,
        },
        presente: {
            type: "boolean",
            nullable: false,
        },
        justificacion: {
            type: "varchar",
            length: 255,
            nullable: true, // Puede ser nulo si no se proporciona
        },
        createdAt: {
            type: "timestamp with time zone",
            default: () => "CURRENT_TIMESTAMP",
            nullable: false,
        },
        updatedAt: {
            type: "timestamp with time zone",
            default: () => "CURRENT_TIMESTAMP",
            onUpdate: "CURRENT_TIMESTAMP",
            nullable: false,
        }
    },
    relations: {
        user: {
            type: "many-to-one",
            target: "User",
            inverseSide: "asistencias",
            joinColumn: { name: "userId", referencedColumnName: "id" },
            cascade: false, // Cambia esto a false o elimínalo
        }
    }
});

export default AsistenciaSchema;
