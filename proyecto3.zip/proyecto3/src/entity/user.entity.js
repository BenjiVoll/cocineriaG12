"use strict";
import { EntitySchema } from "typeorm";
import AsistenciaSchema from './asistencia.entity.js'; // Importar la entidad de asistencia

const UserSchema = new EntitySchema({
    name: "User",
    tableName: "users",
    columns: {
        id: {
            type: "int",
            primary: true,
            generated: true,
        },
        nombreCompleto: {
            type: "varchar",
            length: 255,
            nullable: false,
        },
        telefono: {
            type: "varchar",
            length: 15,
            nullable: false,
        },
        fechaIncorporacion: {
            type: "date",
            nullable: true, // Permitir valores nulos
        },
        cargo: {
            type: "varchar",
            length: 100,
            nullable: false,
        },
        createdAt: {
            type: "timestamp with time zone",
            default: () => "CURRENT_TIMESTAMP",
            nullable: false,
        },
        updatedAt: {
            type: "timestamp with time zone",
            default: () => "CURRENT_TIMESTAMP",
            onUpdate: "CURRENT_TIMESTAMP",
            nullable: false,
        }
    },
    relations: {
        asistencias: { // Relación con la entidad Asistencia
            type: "one-to-many",
            target: "Asistencia",
            inverseSide: "user",
            cascade: true, // Permitir operaciones de cascada
        }
    }
});

export default UserSchema;
